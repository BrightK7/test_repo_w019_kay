

#include "base/intmath.hh"
#include "base/misc.hh"
#include "base/trace.hh"
#include "cpu/pred/gshare.hh"
#include "debug/Fetch.hh"

GShareBP::GShareBP(const Params *params)
    : BPredUnit(params)
{
    
}

void GShareBP::btbUpdate(Addr branch_addr, void * &bp_history)
{

}

bool GShareBP::lookup(Addr branch_addr, void * &bp_history)
{
    return true;
}

void GShareBP::uncondBranch(Addr branch_addr, void * &bp_history)
{

}

void GShareBP::update(Addr branch_addr, bool taken, void *bp_history, bool squashed)
{

}

void GShareBP::squash(void *bp_history) 
{

}

void GShareBP::retireSquashed(void *bp_history)
{

}

GShareBP* 
GShareBPParams::create()
{
    return new GShareBP(this);
}
